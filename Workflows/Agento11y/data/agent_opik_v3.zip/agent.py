import logging
import uuid

from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver  # noqa: E403
from langgraph.graph import StateGraph, MessagesState
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_core.messages import AIMessage
import os
from load_dotenv import load_dotenv

from agent_runtime import AuthContext, AgentRuntimeApp
from mem0 import Memory
import opik
from opik.integrations.langchain import OpikTracer
from psycopg_pool import AsyncConnectionPool


logger = logging.getLogger("agentops-core.agent_test.agent")

load_dotenv()

pool = AsyncConnectionPool(
    conninfo=os.environ.get("MEMORY_DB_URI"),
)
checkpointer_outside = AsyncPostgresSaver(pool)

model_name=os.environ.get("OPENAI_MODEL_NAME", "gpt-3.5-turbo")
api_key=os.environ.get("OPENAI_API_KEY", "")
base_url=os.environ.get("TD_AI_STUDIO_AI_MODELHUB", "https://api.openai.com/v1")
embedding_model_name=os.environ.get("OPENAI_EMBEDDING_MODEL_NAME", "text-embedding-3-small")

llm=ChatOpenAI(model=model_name, api_key=api_key, base_url=base_url, stream_usage=True)
embeddings=OpenAIEmbeddings(model=embedding_model_name, api_key=api_key, base_url=base_url)

mem_db_uri = os.environ.get("MEMORY_DB_URI")
logger.info(f"MEMORY_DB_URI: {mem_db_uri}")

logger.info(f"OpenAI model_name: {model_name}")
logger.info(f"OpenAI api_key: {api_key[:4]}...{api_key[-4:]}")
logger.info(f"OpenAI base_url: {base_url}")

mem = Memory.from_config({
    "vector_store": {"provider": "pgvector", "config": {
        "connection_string": mem_db_uri,
        "collection_name": "mem0_1024"   # Must match your model's dimensions
    }},
    "history_db": {"provider": "postgres", "config": {
        "connection_string": mem_db_uri
    }},
    "llm": {
        "provider": "langchain",
        "config": {
            "model": llm
        }
    },
    "embedder": {
        "provider": "langchain",
        "config": {
            "model": embeddings,
            "embedding_dims": 1024
        }
    }
})

app=AgentRuntimeApp()

def with_session_memory(func):
    def wrapper(state, *args, **kwargs):
        # Extract values from state dict (LangGraph passes state as first arg)
        session_id = state.get("session_id")
        auth_context = state.get("auth_context")
        messages = state.get("messages", [])
        
        if session_id is None:
            session_id = str(uuid.uuid4())
            state["session_id"] = session_id
        
        # Extract user message for memory
        user_message = None
        if messages and isinstance(messages, list):
            for msg in messages:
                if isinstance(msg, dict) and msg.get("role") == "user":
                    user_message = msg.get("content")
                    break
        
        if user_message:
            # Extract user_id from auth_context (handle both object and dict)
            user_id = None
            if auth_context is not None:
                if hasattr(auth_context, 'user_id'):
                    user_id = auth_context.user_id
                elif isinstance(auth_context, dict):
                    user_id = auth_context.get('user_id')
            
            add_session_memory(user_message, session_id, user_id)
        
        return func(state, *args, **kwargs)
    return wrapper

@with_session_memory
def invoke_agent(state):
    print("Invoking agent...")
    # state is expected to be a dict with 'messages' key
    messages = state.get("messages", [])
    # If messages is a list of dicts, convert to string or BaseMessages
    if messages and isinstance(messages[0], dict):
        # Concatenate all user messages for simplicity
        user_content = " ".join([m["content"] for m in messages if m["role"] == "user"])
        llm_response = llm.invoke(user_content)
    else:
        llm_response = llm.invoke(messages)
    # Extract main content from llm_response
    if hasattr(llm_response, "content"):
        res = llm_response.content
    elif hasattr(llm_response, "text"):
        res = llm_response.text
    else:
        res = llm_response
    new_message = AIMessage(content=res)
    # Return a dict with 'messages' key so LangGraph appends it to state
    return {"messages": messages + [new_message]}

def add_session_memory(message, session_id, user_id):
    try:
        # Ensure user_id is a string or None (not a complex object)
        if user_id is not None and not isinstance(user_id, str):
            user_id = str(user_id)
        
        # Ensure session_id is a string
        if session_id is not None and not isinstance(session_id, str):
            session_id = str(session_id)
        
        logger.info(f"Adding session memory - user_id: {user_id}, session_id: {session_id}")
        mem.add([{"role": "user", "content": message}],
                user_id=user_id, run_id=session_id)
        logger.info("Session memory added successfully")
    except Exception as e:
        import traceback
        logger.error(f"Error in add_session_memory: {e}\n{traceback.format_exc()}")
        print(f"Error in add_session_memory: {e}\n{traceback.format_exc()}")
        raise

checkpointer = None
graph = None

@app.entrypoint
async def invoke(message: str, session_id=None, streaming: bool = False, auth_context: AuthContext = None):
    """
    Invoke agent with streaming support.

    Args:
        message: User message
        session_id: Optional session ID for stateful conversations (checkpoint)
        streaming: Enable streaming response via SSE (default: False)
        auth_context: Optional authentication context

    Returns:
        For streaming=False: dict with status/agent_response
        For streaming=True:  AsyncIterator of LangGraph events (main.py handles SSE)
    """
    try:
        g = StateGraph(MessagesState)
        g.add_node("agent", invoke_agent)
        g.add_edge("__start__", "agent")
        graph = g.compile(checkpointer=checkpointer_outside)

        initial_state = {
            "messages": [{"role": "user", "content": message}],
            "session_id": session_id,
            "auth_context": auth_context,
        }

        # Build config: keep thread_id for checkpointer + add OpikTracer
        opik_tracer = OpikTracer()
        config = {
            "configurable": {"thread_id": session_id},
            "callbacks": [opik_tracer],
        }

        if streaming:
            # Return async iterator — main.py pipes this through
            # EventSerializer.stream_events() → EventSourceResponse (SSE).
            # astream_events emits every LLM token, node transition, etc.
            logger.info("Streaming mode enabled, returning astream_events iterator")
            return graph.astream_events(initial_state, config=config, version="v2")

        # Non-streaming: invoke and return the full result
        agent_response = await graph.ainvoke(initial_state, config=config)
        messages = agent_response.get("messages", [])
        ai_messages = [m for m in messages if getattr(m, 'type', None) == 'ai' or getattr(m, 'role', None) == 'assistant']
        last_content = ai_messages[-1].content if ai_messages else None
        response = {
            "status": "success",
            "message": f"Processed: {message}",
            "agent": "my-agent",
            "agent_response": last_content
        }
        return response
    except Exception as e:
        logger.error(e, exc_info=True)
        return {
            "status": "error",
            "message": str(e)
        }
