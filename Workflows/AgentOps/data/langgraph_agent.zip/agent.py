"""Your agent implementation."""
from agent_runtime import agent_runtime_app, AuthContext
from user_agent import create_langgraph_agent
from langchain_core.messages import HumanMessage
import opik
app = agent_runtime_app()


@app.entrypoint
@opik.track
async def invoke(message: str, streaming: bool = False, auth_context: AuthContext = None):
    """
    Invoke agent with streaming support.

    Args:
        message: User message
        streaming: Enable streaming response (default: False)
        auth_context: Optional authentication context

    Returns:
        For streaming=False: Final response string
        For streaming=True: AsyncIterator of dicts
    """
    agent = create_langgraph_agent()

    initial_state = {
        "messages": [HumanMessage(content=message)],
    }

    if not streaming:
        result = await agent.ainvoke(initial_state)
        return result["messages"][-1].content

    # Streaming mode: yield plain dicts — main.py handles SSE formatting.
    # Do NOT yield pre-formatted SSE strings ("data: ...\n\n").
    # The universal serializer in main.py will json.dumps each dict.
    #
    # Supported streaming approaches (uncomment ONE):
    # return agent.astream_events(initial_state, version="v2")  # all LangGraph events
    # return agent.astream(initial_state, stream_mode="messages")  # messages only
    # return agent.astream(initial_state, stream_mode="updates")   # state updates
    #
    # Custom yield (below): iterates astream, extracts node + message content.
    # async def stream_agent():
    #     async for event in agent.astream(initial_state):
    #         for node_name, node_output in event.items():
    #             # Emit node transition event
    #             yield {"type": "agent", "agent": node_name}

    #             if "messages" in node_output:
    #                 for msg in node_output["messages"]:
    #                     if hasattr(msg, "content") and msg.content:
    #                         yield {
    #                             "type": "content",
    #                             "content": msg.content,
    #                             "agent": node_name,
    #                         }

    #     # Completion signal — main.py also appends its own,
    #     # but this lets the client detect end-of-agent-output.
    #     yield {"type": "done"}

    # return stream_agent()
    from opik.integrations.langchain import OpikTracer
    opik_tracer = OpikTracer()
    config = {"callbacks": [opik_tracer]}
    return agent.astream_events(initial_state, config=config, version="v2")
    # return agent.astream(initial_state, config=config,  stream_mode="messages")
    # return agent.astream(initial_state, config=config,  stream_mode="values")
    # return agent.astream(initial_state, config=config,  stream_mode="updates")

    # async def stream_agent():
    #     async for event in agent.astream(initial_state, config=config):
    #         for node_name, node_output in event.items():
    #             yield {"type": "agent", "agent": node_name}
    #             if "messages" in node_output:
    #                 for msg in node_output["messages"]:
    #                     if hasattr(msg, "content") and msg.content:
    #                         yield {"type": "content", "content": msg.content, "agent": node_name}
    #     yield {"type": "done"}

    # return stream_agent()