"""User's LangGraph Agent Implementation - Production-Grade RAG Agent."""
from typing import Annotated, Literal, TypedDict
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_core.messages import BaseMessage, HumanMessage
from langchain_core.tools import tool
from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document
import os


# ============================================================================
# Agent State
# ============================================================================
class AgentState(TypedDict):
    """State for RAG agent with streaming."""
    messages: Annotated[list[BaseMessage], add_messages]
    context: str
    query_analysis: str
    needs_retrieval: bool


# ============================================================================
# Mock Knowledge Base (Replace with real vector DB in production)
# ============================================================================
DOCUMENTS = [
    Document(
        page_content="LangGraph is a framework for building stateful, multi-actor applications with LLMs. "
                    "It provides a way to coordinate multiple LLM calls and manage state between them.",
        metadata={"source": "langgraph_docs", "topic": "framework"}
    ),
    Document(
        page_content="Server-Sent Events (SSE) is a server push technology enabling clients to receive "
                    "automatic updates from a server via HTTP connection. SSE is ideal for streaming.",
        metadata={"source": "mdn_docs", "topic": "streaming"}
    ),
    Document(
        page_content="RAG (Retrieval Augmented Generation) combines information retrieval with language "
                    "generation. It retrieves relevant documents and uses them as context for LLM responses.",
        metadata={"source": "rag_paper", "topic": "rag"}
    ),
    Document(
        page_content="Production-grade agents require proper error handling, observability, and monitoring. "
                    "Streaming responses improve user experience by providing incremental updates.",
        metadata={"source": "best_practices", "topic": "production"}
    ),
]


# ============================================================================
# Vector Store Initialization
# ============================================================================
def initialize_vector_store():
    """Initialize vector store with documents."""
    try:
        embeddings = OpenAIEmbeddings(
            api_key=os.getenv("LLM_API_KEY", ""),
            base_url=os.getenv("LLM_BASE_URL")
        )
        vectorstore = FAISS.from_documents(DOCUMENTS, embeddings)
        return vectorstore.as_retriever(search_kwargs={"k": 2})
    except Exception as e:
        print(f"Warning: Could not initialize vector store: {e}")
        return None


# ============================================================================
# Tools
# ============================================================================
@tool
def retrieve_documents(query: Annotated[str, "Search query for documents"]) -> str:
    """Retrieve relevant documents from the knowledge base."""
    retriever = initialize_vector_store()
    
    if not retriever:
        return "Vector store not available. Using mock results."
    
    try:
        docs = retriever.invoke(query)
        context = "\n\n".join([
            f"Document {i+1}:\n{doc.page_content}"
            for i, doc in enumerate(docs)
        ])
        return context
    except Exception as e:
        return f"Error retrieving documents: {str(e)}"


@tool
def analyze_query(query: Annotated[str, "User query to analyze"]) -> str:
    """Analyze the user query to determine intent and required information."""
    keywords = ["what", "how", "why", "explain", "tell me"]
    is_question = any(kw in query.lower() for kw in keywords)
    
    has_technical_terms = any(term in query.lower() 
                              for term in ["langgraph", "rag", "streaming", "sse"])
    
    analysis = f"Query type: {'Question' if is_question else 'Statement'}\n"
    analysis += f"Technical: {'Yes' if has_technical_terms else 'No'}\n"
    analysis += f"Needs retrieval: {is_question or has_technical_terms}"
    
    return analysis


# ============================================================================
# Agent Graph Creation
# ============================================================================
def create_langgraph_agent():
    """Create a production-grade RAG agent with streaming support.
    
    This agent demonstrates:
    - Document retrieval and processing
    - Multi-step reasoning with streaming
    - State management across conversation turns
    - Production-ready error handling
    
    Returns:
        Compiled LangGraph agent ready for streaming
    """
    # Initialize LLM with streaming
    llm = ChatOpenAI(
        model=os.getenv("LLM_MODEL", "gpt-4"),
        api_key=os.getenv("LLM_API_KEY", ""),
        base_url=os.getenv("LLM_BASE_URL"),
        streaming=True,
        stream_usage=True, 
        temperature=float(os.getenv("TEMPERATURE", "0.7"))
    )
    
    # Define agent nodes
    def analyze_node(state: AgentState) -> AgentState:
        """Analyze the query and decide next steps."""
        messages = state["messages"]
        last_message = messages[-1]
        
        analysis_result = analyze_query.invoke({"query": last_message.content})
        
        state["query_analysis"] = analysis_result
        state["needs_retrieval"] = "needs retrieval: True" in analysis_result.lower()
        
        return state
    
    def retrieve_node(state: AgentState) -> AgentState:
        """Retrieve relevant documents."""
        messages = state["messages"]
        query = messages[-1].content
        
        context = retrieve_documents.invoke({"query": query})
        state["context"] = context
        
        return state
    
    def respond_node(state: AgentState) -> AgentState:
        """Generate response using context."""
        messages = state["messages"]
        context = state.get("context", "")
        
        # Build prompt with context
        if context:
            system_message = f"""You are a helpful AI assistant with access to a knowledge base.
            
Use the following context to answer the user's question:

{context}

If the context doesn't contain relevant information, say so clearly."""
            
            enhanced_messages = [
                {"role": "system", "content": system_message},
                *[{"role": m.type, "content": m.content} for m in messages]
            ]
        else:
            enhanced_messages = messages
        
        # Generate response with streaming
        response = llm.invoke(enhanced_messages)
        
        return {"messages": [response]}
    
    # Build graph
    workflow = StateGraph(AgentState)
    
    # Add nodes
    workflow.add_node("analyze", analyze_node)
    workflow.add_node("retrieve", retrieve_node)
    workflow.add_node("respond", respond_node)
    
    # Add edges
    workflow.add_edge(START, "analyze")
    workflow.add_conditional_edges(
        "analyze",
        lambda state: "retrieve" if state["needs_retrieval"] else "respond",
        {"retrieve": "retrieve", "respond": "respond"}
    )
    workflow.add_edge("retrieve", "respond")
    workflow.add_edge("respond", END)
    
    # Compile and return
    return workflow.compile()


# Note: Agent instance is created in agent.py invoke() function
# This keeps the architecture clean and allows for per-request customization

# # Local testing
if __name__ == "__main__":
    import asyncio
    import json
    import yaml
    from pathlib import Path
    
    # Load config and set env vars BEFORE tests
    config_path = "config.yaml"
    if Path(config_path).exists():
        with open(config_path) as f:
            config = yaml.safe_load(f)
            for key, value in config.get("environment_variables", {}).items():
                os.environ[key] = str(value)
    
    # Reinitialize LLM with loaded config (module was already initialized with empty values)
    import importlib
    import sys
    # Reload this module to reinitialize LLM with proper config
    current_module = sys.modules[__name__]
    llm = ChatOpenAI(
        model=os.getenv("LLM_MODEL", "us.anthropic.claude-sonnet-4-20250514-v1:0"),
        api_key=os.getenv("LLM_API_KEY", ""),
        base_url=os.getenv("LLM_BASE_URL", "http://aiop-btms4.td.teradata.com:4000"),
        streaming=True,
        temperature=0.7
    )
    
    graph = create_langgraph_agent()
    def print_json(data, indent=2):
        """Pretty print JSON-serializable data."""
        try:
            print(json.dumps(data, indent=indent, default=str))
        except:
            print(data)
    
    async def test_streaming():
        """
        Test all LangGraph streaming methods.
        
        LangGraph provides 2 main streaming APIs:
        
        1. graph.astream() - Graph-level streaming with modes:
           - 'updates': State deltas after each node (best for UI progress)
           - 'values': Full state snapshots (good for debugging)
           - 'messages': LLM token streaming (production UX)
           - 'debug': Detailed execution trace (development only)
           - 'custom': User-defined data from nodes
           
        2. graph.astream_events() - Low-level event streaming:
           - Most granular, framework-agnostic events
           - on_chat_model_stream, on_tool_start, on_chain_start, etc.
           - PRODUCTION CHOICE: Best for complex multi-agent systems
           - Provides run_id, parent_ids, tags for distributed tracing
           - Compatible with LangSmith observability
        
        PRODUCTION RECOMMENDATION:
        - Simple agents: astream(stream_mode="messages")
        - Complex/Multi-agent: astream_events(version="v2")
        - Debugging: astream(stream_mode="debug")
        """
        
        # Interactive mode selection
        print("\n" + "="*70)
        print("LangGraph Streaming Test Suite")
        print("="*70)
        print("\nSelect streaming mode to test:")
        print("  1. Updates - State deltas after each node")
        print("  2. Values - Full state snapshots")
        print("  3. Messages - LLM token streaming (PRODUCTION)")
        print("  4. Debug - Detailed execution trace")
        print("  5. Multiple - Updates + Messages combined")
        print("  6. Events - Low-level events (PRODUCTION)")
        print("  7. All - Run all modes sequentially")
        print("\nEnter choice (1-7) [default: 3]: ", end="", flush=True)
        
        try:
            choice = input().strip() or "3"
            mode_choice = int(choice)
        except:
            mode_choice = 3
        
        queries = [
            "What is LangGraph and how does streaming work?"
        ]
        
        for query in queries:
            print(f"\n{'='*70}")
            print(f"Query: {query}")
            print('='*70)
            
            input_data = {
                "messages": [HumanMessage(content=query)]
            }
            
            # 1. Stream mode: updates (state changes after each node)
            if mode_choice in [1, 7]:
                print("\n[1. UPDATES - State deltas after each node]")
                print("-" * 70)
                async for chunk in graph.astream(input_data, stream_mode="updates"):
                    for node, update in chunk.items():
                        print(f"  {node}:")
                        print_json({k: str(v)[:100] for k, v in update.items()})
            
            # 2. Stream mode: values (complete state snapshots)
            if mode_choice in [2, 7]:
                print("\n[2. VALUES - Full state after each step]")
                print("-" * 70)
                async for chunk in graph.astream(input_data, stream_mode="values"):
                    messages = chunk.get("messages", [])
                    if messages:
                        last = messages[-1]
                        content_preview = last.content[:80] + "..." if len(last.content) > 80 else last.content
                        print(f"  State: messages={len(messages)}, context_len={len(chunk.get('context', ''))}")
                        print(f"  Last message: {content_preview}")
            
            if mode_choice in [8]:
                print("\n[8. CUSTOM MODE - SSE-style output]")
                print("-" * 70)
                full_response = ""
                async for event in graph.astream(input_data):
                    for node_name, node_output in event.items():
                        # Stream node info
                        print(f"data: {json.dumps({'type': 'agent', 'agent': node_name})}\n")
                        print(f"  [node_output: {node_output}] ")
                        
                        if "messages" in node_output:
                            for msg in node_output["messages"]:
                                if hasattr(msg, "content"):
                                    content = msg.content
                                    full_response += content
                                    
                                    # Stream content
                                    print(f"data: {json.dumps({'type': 'content', 'content': content})}\n")
                print(f"\n  Full response: {full_response}\n")
            
            
            # 3. Stream mode: messages (LLM token streaming)
            if mode_choice in [3, 7]:
                print("\n[3. MESSAGES - LLM tokens in real-time]")
                print("-" * 70)
                print("  Output: ", end="", flush=True)
                async for chunk in graph.astream(input_data, stream_mode="messages"):
                    for node_name, node_output in chunk.items():
                        print(f"\n  [Node: {node_name}] ", end="", flush=True)
                        print(f"")
                    # print(chunk, end="", flush=True)
                    print("\n")
                    # if msg.content:
                    #     print(msg.content, end="", flush=True)
                print("\n")
            
            # 4. Stream mode: debug (comprehensive execution trace)
            if mode_choice in [4, 7]:
                print("\n[4. DEBUG - Detailed execution trace]")
                print("-" * 70)
                async for chunk in graph.astream(input_data, stream_mode="debug"):
                    if "type" in chunk:
                        print(f"  [{chunk['type']}] {chunk.get('step', '')} - {chunk.get('name', '')}")
            
            # 5. Multiple modes (updates + messages)
            if mode_choice in [5, 7]:
                print("\n[5. MULTIPLE MODES - Updates + Messages combined]")
                print("-" * 70)
                async for mode, chunk in graph.astream(input_data, stream_mode=["updates", "messages"]):
                    if mode == "updates":
                        for node in chunk.keys():
                            print(f"\n  [Node: {node}] ", end="", flush=True)
                    elif mode == "messages":
                        msg, _ = chunk
                        if msg.content:
                            print(msg.content, end="", flush=True)
                print("\n")
            
            # 6. astream_events - PRODUCTION-LEVEL (most granular)
            if mode_choice in [6, 7]:
                print("\n[6. ASTREAM_EVENTS - Low-level event stream (PRODUCTION)]")
                print("-" * 70)
                print("  Output: ", end="", flush=True)
                event_count = {"chat": 0, "tool": 0, "chain": 0}
                async for event in graph.astream_events(input_data, version="v2"):
                    print_json(event, indent=4)
                    # event_type = event.get("event", "")
                    
                    # # Track LLM streaming
                    # if event_type == "on_chat_model_stream":
                    #     chunk = event.get("data", {}).get("chunk", {})
                    #     if hasattr(chunk, "content") and chunk.content:
                    #         print(chunk.content, end="", flush=True)
                    #         event_count["chat"] += 1
                    
                    # # Track tool calls
                    # elif event_type == "on_tool_start":
                    #     tool_name = event.get("name", "unknown")
                    #     print(f"\n  [Tool: {tool_name}] ", end="", flush=True)
                    #     event_count["tool"] += 1
                    
                    # # Track node execution
                    # elif event_type == "on_chain_start":
                    #     node = event.get("metadata", {}).get("langgraph_node")
                    #     if node:
                    #         event_count["chain"] += 1
                
                print(f"\n\n  📊 Event Summary:")
                print_json(event_count, indent=4)
    
    asyncio.run(test_streaming())

